﻿using System;
using AmoToSheetFunction;
using Newtonsoft.Json;

namespace AmoToSheetFunc
{
    public class AmoToSheetFunction
    {
        public YaCloudFunctionResponseBase FunctionHandler(string? request = null)
        {
            if (request == null) return new YaCloudFunctionErrorResponse
            {
                ErrorMessage = "empty request",
                ErrorType = "RequestError"
            };
            
            Console.WriteLine("REQUEST: " + request);
            var amoRequest = JsonConvert.DeserializeObject<AmoHookRequest>(request);
            Console.WriteLine("BODY: " + amoRequest.body);
            
            return new YaCloudFunctionResponse();
        }
    }
}
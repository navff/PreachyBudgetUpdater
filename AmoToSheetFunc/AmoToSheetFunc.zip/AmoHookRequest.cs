﻿namespace AmoToSheetFunction
{
    public class AmoHookRequest
    {
        public string httpMethod { get; set; }
        //public string headers { get; set; }
        public string body { get; set; }
    }
}
﻿namespace UpdaterCloudFunction.Common
{
    public class TinkoffApiSettings
    {
        public string AuthToken { get; set; }
        public string ApiUrl { get; set; }
    }
}

